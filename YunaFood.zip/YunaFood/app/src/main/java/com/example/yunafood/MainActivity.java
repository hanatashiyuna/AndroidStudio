package com.example.yunafood;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yunafood.adapters.UserDetailAdapter;
import com.example.yunafood.models.UserDetail;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    List<UserDetail> dataList = new ArrayList<>();
    UserDetailAdapter userDetailAdapter;
    int currentIndex = -1;

    private static final int REQUEST_CALL = 1;
    private TextView mTextViewNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //init list view
        listView = findViewById(R.id.lv_user);
        onSetData();


        userDetailAdapter = new UserDetailAdapter(MainActivity.this, R.layout.contact_item, dataList);
        listView.setAdapter(userDetailAdapter);

        //register content menu
        registerForContextMenu(listView);

    }



    private void onSetData() {
        //fake data
        dataList.add(new UserDetail(R.drawable.ic_baseline_account_circle_24, "Nam", "nam@gmail.com", "0311223344"));
        dataList.add(new UserDetail(R.drawable.ic_baseline_account_circle_24, "Mavis", "mavis@gmail.com", "0311333333"));
        dataList.add(new UserDetail(R.drawable.ic_baseline_account_circle_24, "Thien", "thien@gmail.com", "0311111111"));
        dataList.add(new UserDetail(R.drawable.ic_baseline_account_circle_24, "Thang", "thang@gmail.com", "0311001133"));
        dataList.add(new UserDetail(R.drawable.ic_baseline_account_circle_24, "Yuna", "yuna@gmail.com", "0301001027"));
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_content, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int index = info.position;
        switch (item.getItemId()) {
            case R.id.edit:
                this.currentIndex = index;
                showDialogAdd();
                return true;
            case R.id.delete:
                dataList.remove(index);
                userDetailAdapter.notifyDataSetChanged();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.add_menu:
                showDialogAdd();
                return true;
            case R.id.logout:
                logOut();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void logOut() {
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
    }

    private void showDialogAdd() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_user, null);

        final EditText edName = view.findViewById(R.id.df_name);
        final EditText edPhone = view.findViewById(R.id.df_phone);
        final EditText edEmail = view.findViewById(R.id.df_email);
        if (currentIndex >= 0) {
            edName.setText(dataList.get(currentIndex).getName());
            edPhone.setText(String.valueOf(dataList.get(currentIndex).getPhone()));
            edEmail.setText(dataList.get(currentIndex).getEmail());
        }

        builder.setView(view);
        builder.setTitle("Add/Edit User")
                .setPositiveButton("Save User", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String name = edName.getText().toString();
                        String email = edEmail.getText().toString();
                        String phone = edPhone.getText().toString();

                        if (currentIndex >= 0) {
                            dataList.get(currentIndex).setName(name);
                            dataList.get(currentIndex).setEmail(email);
                            dataList.get(currentIndex).setPhone(phone);
                            currentIndex = -1;
                        } else {
                            UserDetail userDetailAdapter = new UserDetail(R.drawable.ic_baseline_account_circle_24, name, email, phone);
                            dataList.add(userDetailAdapter);
                        }

                        userDetailAdapter.notifyDataSetChanged();

                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });

        builder.show();
    }

}