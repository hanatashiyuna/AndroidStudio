package com.example.yunafood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        EditText username = (EditText) findViewById(R.id.editText);
        EditText password = (EditText) findViewById(R.id.editText2);
        EditText email = (EditText) findViewById(R.id.editText3);
        Button buttonRegister = (Button) findViewById(R.id.button);

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(username.getText().toString().equals("yuna") && password.getText().toString().equals("yuna") && email.getText().toString().equals("yuna@gmail.com")){
                    //correct
                    Toast.makeText(RegistrationActivity.this, "REGISTER SUCCESSFULL", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                    startActivity(intent);
                }else
                    //incorrect
                    Toast.makeText(RegistrationActivity.this, "REGISTER FAILED", Toast.LENGTH_SHORT).show();

            }
        });
    }


    public void SignIn(View view) {
        startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
    }
}