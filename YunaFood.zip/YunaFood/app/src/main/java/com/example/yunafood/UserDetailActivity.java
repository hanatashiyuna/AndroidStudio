package com.example.yunafood;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.yunafood.models.UserDetail;

public class UserDetailActivity extends AppCompatActivity {
    TextView detailUsn, detailPhone, detailEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        detailUsn = findViewById(R.id.detail_usn);
        detailPhone = findViewById(R.id.detail_phone);
        detailEmail = findViewById(R.id.detail_email);

        onGetIntent();
    }

    private void onGetIntent() {
        Intent intent = getIntent();
        UserDetail model = (UserDetail) intent.getSerializableExtra("Yuna");
        detailUsn.setText(String.format("Name: %s", model.getName()));
        detailPhone.setText(String.format("Phone: %s", model.getPhone()));
        detailEmail.setText(String.format("Email: %s", model.getEmail()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_back, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.back:
                goBack();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void goBack() {
        Intent intent = new Intent(UserDetailActivity.this, MainActivity.class);
        startActivity(intent);
    }

}