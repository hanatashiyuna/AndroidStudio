package com.example.yunafood.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.yunafood.MainActivity;
import com.example.yunafood.R;
import com.example.yunafood.UserDetailActivity;
import com.example.yunafood.models.UserDetail;

import java.util.List;

public class UserDetailAdapter extends BaseAdapter {
    private Context mContext;
    private List<UserDetail> dataList;
    private int mResources;

    public UserDetailAdapter(Context mContext, int resources , List<UserDetail> dataList){
        this.mContext = mContext;
        this.mResources = resources;
        this.dataList = dataList;
    }


    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int i) {
        return dataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (viewHolder == null){
            convertView = LayoutInflater.from(mContext).inflate(mResources,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.textViewName = convertView.findViewById(R.id.tv_usnname);
            viewHolder.textViewPhone = convertView.findViewById(R.id.tv_phone);
            viewHolder.textViewEmail = convertView.findViewById(R.id.tv_email);
            viewHolder.btnAvatar = convertView.findViewById(R.id.imageViewUsn);
            viewHolder.btnCall = convertView.findViewById(R.id.imageViewCall);
        }
        else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        UserDetail model = dataList.get(position);
        viewHolder.textViewName.setText(String.valueOf(model.getName()));
        viewHolder.textViewPhone.setText(String.valueOf(model.getPhone()));
        viewHolder.textViewEmail.setText(String.valueOf(model.getEmail()));
        viewHolder.btnAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, UserDetailActivity.class);
                intent.putExtra("Yuna", model);
                mContext.startActivity(intent);
            }
        });
        viewHolder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel: " + model.getPhone()));
                mContext.startActivity(intent);
            }
        });


        return convertView;
    }

    public class ViewHolder{
        ImageView btnAvatar;
        ImageView btnCall;
        TextView textViewName;
        TextView textViewPhone;
        TextView textViewEmail;
    }
}


